import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Collections;
import java.util.LinkedList;

/**
 * Class sets up the MainForm and paint
 */
public class MainForm extends JFrame implements ActionListener {
    //Main panel holds other panels
    JPanel pnlMain;
    //Components on Header========================
    JPanel pnlHead;
    JLabel lblClient, lblSite, lblRoom, lblDate;
    JTextField txtClient, txtSite, txtRoom, txtDate;
    //=========================================================

    //Components on Color Panel========================
    JPanel pnlColor, pnlGrid, pnlButtons;
    JButton btnNewOrLoad;
    JLabel lblColor, lblBlank_0,lblBlank_1, lblBlank_2;
    JButton btnGreen, btnYellow, btnPurple, btnBlue, btnRed, btnWhite, btnMove;
    //=====================================================================

    //Components on Grid
    JLabel[] lblGridRow, lblGridColumn;
    JTextField[][] txtGrid;

    //Components on Footer============
    JButton btnClear, btnSave, btnSort, btnFind, btnRAF, btnExit;
    JLabel lblSearch, lblBlank_3, lblBlank_4, lblBlank_5;
    JTextField txtSearch;
    //============================================================

    FileIO fileIo = new FileIO();

    //variables for grid size============
    int row;
    int column;

    //Variables for color picked and mobility picked
    String color ="#FFFFFF";
    String mobility = "Yes";

    //variables use to handle the search function
    SheetData statusBeforeFind;
    //boolean btnFindPressed = false;

    /**
     * Set up the layout of the MainForm
     * @param row       number of rows of the Grid
     * @param column    number of column of the Grid
     */
    public MainForm(int row, int column) {
        this.row = row;
        this.column = column;

        this.setTitle("Room Plan");//default BorderLayout
        this.setLocation(50, 50);
        this.setResizable(false);

        //Overwrite windowClosing
        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });


        this.pnlMain = new JPanel();
        pnlMain.setLayout(new BoxLayout(pnlMain, BoxLayout.Y_AXIS));
        //MainFrame==================
        //start head section======
        this.pnlHead = new JPanel();
        pnlHead.setBackground(Color.decode("#FFCF96"));

        lblClient = new JLabel(" Client: ");
        txtClient = new JTextField(12);//add listener?
        lblSite = new JLabel("Site: ");
        txtSite = new JTextField(12);
        lblRoom = new JLabel(" Room: ");
        txtRoom = new JTextField(12);
        lblDate = new JLabel(" Date: ");
        txtDate = new JTextField(12);

        pnlHead.add(lblClient);
        pnlHead.add(txtClient);
        pnlHead.add(lblSite);
        pnlHead.add(txtSite);
        pnlHead.add(lblRoom);
        pnlHead.add(txtRoom);
        pnlHead.add(lblDate);
        pnlHead.add(txtDate);
        //end title section======

        //start color section======
        this.pnlColor = new JPanel();

        btnNewOrLoad = new JButton("New or Load");
        btnNewOrLoad.setPreferredSize(new Dimension(110, 25));
        btnNewOrLoad.addActionListener(this);

        lblBlank_1 = new JLabel();
        lblBlank_1.setPreferredSize(new Dimension(65, 25));

        lblColor = new JLabel("Select Color : ");
        lblColor.setPreferredSize(new Dimension(80, 25));

        btnRed = new JButton();
        btnRed.setPreferredSize(new Dimension(80, 25));
        btnRed.addActionListener(this);
        btnRed.setBackground(Color.decode("#FBA1B7"));

        btnYellow = new JButton();
        btnYellow.setPreferredSize(new Dimension(80, 25));
        btnYellow.addActionListener(this);
        btnYellow.setBackground(Color.decode("#FAF0D7"));

        btnGreen = new JButton();
        btnGreen.setPreferredSize(new Dimension(80, 25));
        btnGreen.addActionListener(this);
        btnGreen.setBackground(Color.decode("#F3FDE8"));

        btnBlue = new JButton();
        btnBlue.setPreferredSize(new Dimension(80, 25));
        btnBlue.addActionListener(this);
        btnBlue.setBackground(Color.decode("#D2E0FB"));

        btnPurple = new JButton();
        btnPurple.setPreferredSize(new Dimension(80, 25));
        btnPurple.addActionListener(this);
        btnPurple.setBackground(Color.decode("#D8B4F8"));

        btnWhite = new JButton();
        btnWhite.setPreferredSize(new Dimension(80, 25));
        btnWhite.addActionListener(this);
        btnWhite.setBackground(Color.decode("#FFFFFF"));

        lblBlank_2 = new JLabel();
        lblBlank_2.setPreferredSize(new Dimension(65, 25));

        btnMove = new JButton("Non-Fixed");
        btnMove.setPreferredSize(new Dimension(100, 25));
        btnMove.addActionListener(this);

        pnlColor.add(btnNewOrLoad);
        pnlColor.add(lblBlank_1);
        pnlColor.add(lblColor);
        pnlColor.add(btnRed);
        pnlColor.add(btnYellow);
        pnlColor.add(btnGreen);
        pnlColor.add(btnBlue);
        pnlColor.add(btnPurple);
        pnlColor.add(btnWhite);
        pnlColor.add(lblBlank_2);
        pnlColor.add(btnMove);
        //end color section======

        //start grid section
        this.pnlGrid = new JPanel();
        pnlGrid.setLayout(new GridLayout(row + 1, column + 1, -1, -1));

        lblBlank_0 = new JLabel("");
        pnlGrid.add(lblBlank_0);

        //Create labels showing columns from left to right
        for (int i = 0; i < column; i++) {
            lblGridColumn = new JLabel[column];
            lblGridColumn[i] = new JLabel(Integer.toString(i));
            lblGridColumn[i].setPreferredSize(new Dimension(20, 20));
            lblGridColumn[i].setHorizontalAlignment(JLabel.CENTER);
            lblGridColumn[i].setForeground(Color.GRAY);
            pnlGrid.add(lblGridColumn[i]);

        }

        txtGrid = new JTextField[row][column];

        //Create labels showing Rows from Top to Down
        for (int i = 0; i < row; i++) {
            lblGridRow = new JLabel[row];
            lblGridRow[i] = new JLabel(Integer.toString(i));
            lblGridRow[i].setPreferredSize(new Dimension(20, 20));
            lblGridRow[i].setHorizontalAlignment(JLabel.CENTER);
            lblGridRow[i].setForeground(Color.GRAY);
            pnlGrid.add(lblGridRow[i]);

            //Create text fields showing Grids from Left to Right then Top to Down
            for (int j = 0; j < column; j++) {
                txtGrid[i][j] = new JTextField();
                txtGrid[i][j].setHorizontalAlignment(JTextField.CENTER);
                txtGrid[i][j].setPreferredSize(new Dimension(20, 20));
                txtGrid[i][j].setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1));

                //MouseListener setting single cell Color and Mobility(by cell Name)******@@@@@@******@@@@@@
                txtGrid[i][j].addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        JTextField textField = (JTextField) e.getSource();
                        textField.setBackground(Color.decode(color));

                        if (mobility.equals("Yes")) {
                            textField.setName("Yes");
                            textField.setBorder(new LineBorder(Color.LIGHT_GRAY));
                        } else {
                            textField.setName("No");
                            textField.setBorder(BorderFactory.createLineBorder(Color.GRAY, 3));
                        }
                    }
                });
                pnlGrid.add(txtGrid[i][j]);
            }
        }
        //end grid section


        //start Footer section======
        this.pnlButtons = new JPanel();
        btnClear = new JButton("Clear");
        btnClear.addActionListener(this);
        btnSave = new JButton("Save CSV");
        btnSave.addActionListener(this);
        btnSort = new JButton("Sort");
        btnSort.addActionListener(this);

        lblBlank_3 = new JLabel();
        lblBlank_3.setPreferredSize(new Dimension(40, 20));

        lblBlank_4 = new JLabel();
        lblBlank_4.setPreferredSize(new Dimension(40, 20));

        lblBlank_5 = new JLabel();
        lblBlank_5.setPreferredSize(new Dimension(40, 20));

        lblSearch = new JLabel("Search: ");
        txtSearch = new JTextField(" by Furniture");
        txtSearch.setPreferredSize(new Dimension(80, 20));
        btnFind = new JButton("Find");
        btnFind.addActionListener(this);
        btnRAF = new JButton("Save RAF");
        btnRAF.addActionListener(this);
        btnExit = new JButton("Exit");
        btnExit.addActionListener(this);

        pnlButtons.add(btnClear);
        pnlButtons.add(btnSort);
        pnlButtons.add(lblBlank_3);
        pnlButtons.add(btnSave);
        pnlButtons.add(btnRAF);
        pnlButtons.add(lblBlank_4);
        pnlButtons.add(lblSearch);
        pnlButtons.add(txtSearch);
        pnlButtons.add(btnFind);
        pnlButtons.add(lblBlank_5);
        pnlButtons.add(btnExit);
        //end buttons section======


        //end MainFrame==================

        //pack Panels onto MainPanel, MainPanel onto MainFrame
        pnlMain.add(pnlHead);
        pnlMain.add(pnlColor);
        pnlMain.add(pnlGrid);
        pnlMain.add(pnlButtons);
        this.add(pnlMain);
        this.pack();
        this.setVisible(true);

    }

    /**
     * Recover the MainForm to the condition before Find button was clicked
     * @param sheetData status how the Grid to be recovered
     */
    private void RecoverGrid(SheetData sheetData)
    {
        int counter = 0;

        while(sheetData._cellDatum[counter] != null)
        {
            txtGrid[sheetData._cellDatum[counter]._row][sheetData._cellDatum[counter]._column].setText(sheetData._cellDatum[counter]._fixture);
            txtGrid[sheetData._cellDatum[counter]._row][sheetData._cellDatum[counter]._column].setBackground(Color.decode(sheetData._cellDatum[counter]._color));
            txtGrid[sheetData._cellDatum[counter]._row][sheetData._cellDatum[counter]._column].setName(sheetData._cellDatum[counter]._mobility);
            counter++;
        }

        for(int i = 0; i < row; i++)
        {
            for (int j = 0; j < column; j++)
            {
                //First check if TextField object on the txtArray has Name, if so, then check name
                if(txtGrid[i][j].getName() != null && txtGrid[i][j].getName().equals("No"))
                {
                    txtGrid[i][j].setBorder(BorderFactory.createLineBorder(Color.GRAY, 3));
                }
            }
        }
    }

    /**
     * Indicate where file to be saved
     * @param extension type of file to be saved
     * @return
     */
    private String SelectFilePath(String extension) {
        //Creates a file dialog (file explorer window) to allow the user to select where they want to save their file.
        FileDialog dialog = new FileDialog(this, "Select Save Location", FileDialog.SAVE);
        //Set the default file name for the save file. This can be changes by the user in the dialog.
        dialog.setFile("Untitled" + extension);
        //Make the file dialog visible on screen. This will lock the parent screen until the user is finished with the dialog.
        dialog.setVisible(true);

        //Get the slected file name provided by the user
        String fileName = dialog.getFile();
        //If the file name is empty or is just the extension type without any name before it. Return null.
        if (fileName == null || fileName.isEmpty() || fileName.equalsIgnoreCase(extension)) {
            return null;
        }
        //If the filename extension has been changed and no longer matches the provided extension type.
        //NOTE: You might not always do this step if you want to allow the user to pick their own extension type.
        if (fileName.endsWith(extension) == false) {
            //Split the filename into sections
            String[] temp = fileName.split("\\.");
            //Take the first part fo the file name (the name section) and add the file extension back to the end of it.
            fileName = temp[0] + extension;
        }
        //Get the file directory that we chose to save the file in and add the file's name to the end of the path.
        String filePath = dialog.getDirectory() + fileName;
        //Return the full file path back to where the method was called.
        return filePath;
    }

    /**
     * Store data necessary on the MainForm to Object SheetData
     * @return
     */
    private SheetData TransferDataToObject()
    {
        SheetData sheetData = new SheetData();

        sheetData._row = row-1;
        sheetData._column = column-1;
        sheetData._client = txtClient.getText();
        sheetData._site = txtSite.getText();
        sheetData._room = txtRoom.getText();
        sheetData._date = txtDate.getText();

        //Fix the cellData Array size to 2500, modified required if row*column > 2500
        CellData[] cellDatum= new CellData[2500];

        int counter = 0;

        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < column; j++)
            {
                CellData cellData = new CellData();

                if(txtGrid[i][j].getText().isEmpty())
                {
                    continue;
                }

                    cellData._row = i;
                    cellData._column = j;
                    cellData._fixture = txtGrid[i][j].getText();

                    String str = String.format("#%06X", txtGrid[i][j].getBackground().getRGB());

                    //Delete FF after #
                    cellData._color = str.charAt(0) + str.substring(3);

                    cellData._mobility = txtGrid[i][j].getName();
                    cellDatum[counter] = cellData;

                    counter++;
            }

        }
            sheetData._cellDatum = cellDatum;


        return  sheetData;

    }

    /**
     * Create and fill a popup Page showing furniture statistic on the Grid
     */
    private void PopulateSortForm() {
        //Create a list to hold the text values and their counts
        LinkedList<DataForSort> fixtureCountList = new LinkedList<>();

        //Cycle through the 2D array of fields
        for (int x = 0; x < txtGrid.length; x++) {
            for (int y = 0; y < txtGrid[x].length; y++) {
                //If the current field is empty, skip to the next loop cycle
                if (txtGrid[x][y].getText().isEmpty()) {
                    continue;
                }
                String fixture = txtGrid[x][y].getText();
                //Check if the current text is already in the list
                int index = CheckListForItem(fixtureCountList, fixture);
                //If not, add it
                if (index == -1) {
                    //Add the fixture to the list with a count of 1
                    fixtureCountList.add(new DataForSort(fixture, 1));
                }
                //If so, increase the count for that item
                else {
                    //Go to the index where the fixture was found and increase its count by 1
                    fixtureCountList.get(index)._count++;
                }
            }
        }
        //Sort the list - this requires the comparable interface to be applied to the TextDetails objects in the list.
        Collections.sort(fixtureCountList);
        //Pass the list to the sort form and open it on screen
        new SortPage(fixtureCountList);
    }

    /**
     * Compare Text on the current cell and the Text recorded from previous cells read
     * @param fixtureCountList  records of previous cells read
     * @param fixture   Text of the current cell read
     * @return
     */
    private int CheckListForItem(LinkedList<DataForSort> fixtureCountList, String fixture) {
        //Cycle through the current list of fixture
        for (int i = 0; i < fixtureCountList.size(); i++) {
            //Get the index of the current loop and check if the fixture value of that entry
            //matches the provided fixture parameter.
            if (fixtureCountList.get(i)._fixture.equalsIgnoreCase(fixture)) {
                //Return the index of where the word was found.
                return i;
            }
        }
        //Return -1 which will be treated as a not found value.
        return -1;
    }

    /**
     * Action listener responding to buttons click on the MainForm
     * @param e the event to be processed
     */
    public void actionPerformed(ActionEvent e) {

        //popup the NewOrLoad window
        if (e.getSource() == btnNewOrLoad) {
            new NewOrLoad();
            this.setVisible(false);
        }

        //Clean up all Grids
        if (e.getSource() == btnClear) {

            for (int i = 0; i < row; i++) {
                for (int j = 0; j < column; j++) {
                    txtGrid[i][j].setText("");
                }
            }
            //Repaint the Grid Panel to show borderline properly
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    pnlGrid.repaint();
                }
            });
        }

        //Sort and show furniture statics on the Grid
        if (e.getSource() == btnSort) {
            PopulateSortForm();
        }

        //Click Exit to quite the app
        if (e.getSource() == btnExit) {
            System.exit(0);
        }


        //Click to save CSV file and DAT file
        if (e.getSource() == btnSave) {
            //Make the user select where they want to save and get the location and file name selected.
            String filePath = SelectFilePath(".csv");

            //Store current Frame data on the Screen to an Object
            SheetData sheetData = TransferDataToObject();
            //Pass the Object to the file manager to be saved to the data file.
            fileIo.SaveTo_Csv(sheetData, filePath);
            fileIo.SaveTo_DAT(sheetData, filePath);
        }

        //Click to save RAF file
        if (e.getSource() == btnRAF) {
            //Make the user select where they want to save and get the location and file name selected.
            String filePath = SelectFilePath(".raf");

            //Store current Frame data on the Screen to an Object
            SheetData sheetData = TransferDataToObject();
            //Pass the Object to the file manager to be saved to the data file.
            fileIo.SaveTo_Raf(sheetData, filePath);
        }

        //Pick Red color to fill the cell to be clicked
        if (e.getSource() == btnRed) {
            color = "#FBA1B7";
            btnRed.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));

            btnYellow.setBorder(null);
            btnGreen.setBorder(null);
            btnBlue.setBorder(null);
            btnPurple.setBorder(null);
            btnWhite.setBorder(null);
        }

        //Pick Yellow color to fill the cell to be clicked
        if (e.getSource() == btnYellow) {
            color = "#FAF0D7";
            btnYellow.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));

            btnRed.setBorder(null);
            btnGreen.setBorder(null);
            btnBlue.setBorder(null);
            btnPurple.setBorder(null);
            btnWhite.setBorder(null);
        }

        //Pick Green color to fill the cell to be clicked
        if (e.getSource() == btnGreen) {
            color = "#F3FDE8";
            btnGreen.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));

            btnRed.setBorder(null);
            btnYellow.setBorder(null);
            btnBlue.setBorder(null);
            btnPurple.setBorder(null);
            btnWhite.setBorder(null);
        }

        //Pick Blue color to fill the cell to be clicked
        if (e.getSource() == btnBlue) {
            color = "#D2E0FB";
            btnBlue.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));

            btnRed.setBorder(null);
            btnYellow.setBorder(null);
            btnGreen.setBorder(null);
            btnPurple.setBorder(null);
            btnWhite.setBorder(null);
        }

        //Pick Purple color to fill the cell to be clicked
        if (e.getSource() == btnPurple) {
            color = "#D8B4F8";
            btnPurple.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));

            btnRed.setBorder(null);
            btnYellow.setBorder(null);
            btnGreen.setBorder(null);
            btnBlue.setBorder(null);
            btnWhite.setBorder(null);
        }

        //Pick White color to fill the cell to be clicked
        if (e.getSource() == btnWhite) {
            color = "#FFFFFF";
            btnWhite.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));

            btnRed.setBorder(null);
            btnYellow.setBorder(null);
            btnGreen.setBorder(null);
            btnBlue.setBorder(null);
            btnPurple.setBorder(null);
        }

        //Choose whether the cell to be clicked filled with movable or Not furniture
        if (e.getSource() == btnMove) {
            if (mobility.equals("Yes")) {
                mobility = "No";
                btnMove.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
                btnMove.setText("Fixed");
            } else {
                mobility = "Yes";
                btnMove.setBorder(null);
                btnMove.setText("Non-Fixed");
            }
        }

        //Click to search for a particular furniture OR recover the Grid to before search condition
       if(e.getSource() == btnFind)
       {
           //flag whether matched item found on the Grid
           boolean match = false;

           if(btnFind.getText().equals("Find"))
           {
               //Record the current Grid status
               statusBeforeFind = TransferDataToObject();

               //Popup a message if the search textField is empty
               if(txtSearch.getText().isEmpty())
               {
                   JOptionPane.showMessageDialog(this,"Please enter Furniture Name for Searching.");
               }
               else
               {
                   //Try to run Foreach loop a 2D array
                   for (JTextField[] txtOut : txtGrid) {
                       for (JTextField txtIn : txtOut) {
                           if (txtIn.getText().equalsIgnoreCase(txtSearch.getText())) {
                               match = true;
                               txtIn.setBackground(Color.decode("#D8B4F8"));
                           }
                       }
                   }
                   if (match) {
                       for (JTextField[] txtOut : txtGrid) {
                           for (JTextField txtIn : txtOut) {
                               if (!txtIn.getText().equalsIgnoreCase(txtSearch.getText())) {
                                   txtIn.setBackground(Color.decode("#FFFFFF"));
                               }
                               txtIn.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1));
                           }
                       }

                       SwingUtilities.invokeLater(new Runnable() {
                           @Override
                           public void run() {
                               repaint();
                           }
                       });

                       btnFind.setText("UNDO");
                   }

                   //If no match Furniture found, pop up a message
                   else {
                       JOptionPane.showMessageDialog(this, "Furniture Not found.");
                   }
               }
           }
           else
           {
               RecoverGrid(statusBeforeFind);
               btnFind.setText("Find");
           }
       }
    }
}
