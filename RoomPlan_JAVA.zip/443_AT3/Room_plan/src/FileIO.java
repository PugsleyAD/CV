import java.io.*;

/**
 * Class handling how data write and read from File e.g. CSV RAF DAT.
 */
public class FileIO
{
    /**
     * Save data to a CSV file
     * @param sheetData store data to be saved
     * @param filePath where the CSV File to be saved
     */
    public void SaveTo_Csv(SheetData sheetData, String filePath)
    {
        try
        {
            //Create a buffered writer to connect to our specified file and perform the writing operations
            BufferedWriter buffer = new BufferedWriter(new FileWriter(filePath));

            //Write the headings data to the file before we write the grid data
            buffer.write("Row: ," + sheetData._row);
            buffer.newLine();
            buffer.write("Column: ," + sheetData._column);
            buffer.newLine();

            buffer.write("Client: ," + sheetData._client);
            buffer.newLine();
            buffer.write("Site: ," + sheetData._site);
            buffer.newLine();
            buffer.write("Room: ," + sheetData._room);
            buffer.newLine();
            buffer.write("Date: ," + sheetData._date);
            buffer.newLine();

            //Number count number of cellData on the Grid
            int i = 0;

            //_cellDatum was set to be [2500], read each _cellDatum until _cellDatum[i] is empty
            while (sheetData._cellDatum[i] != null)
            {
                //Write the current element, followed by a comma, on the current line of the file
                buffer.write( sheetData._cellDatum[i]._column + "," +  sheetData._cellDatum[i]._row +
                        "," + sheetData._cellDatum[i]._fixture + "," + ColorTrans(sheetData._cellDatum[i]._color) +
                        "," + sheetData._cellDatum[i]._mobility);

                //Move to next line of cellData
                i++;

                //Start a new line once the current row is finished
                buffer.newLine();
            }

            //Close the file buffer once writing is finished
            buffer.close();
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }

    /**
     * Read data from CSV file
     * @param filePath where to find the file to be read
     * @return
     */
    public SheetData Read_Csv(String filePath)
    {

        //A Object hold Frame data
        SheetData sheetData = new SheetData();

        //Object Array hold Grid data
        CellData[] cellDatum = new CellData[2500];

        //Try catch block is required in Java for any operations dealing with an external resource
        //such as a file or database
        try
        {
            //Create a buffered reader class object to read file
            BufferedReader buffer = new BufferedReader(new FileReader(filePath));

            //Read number of rows and column of the Grid needed to be created
            //Neither shown in the Frame
            sheetData._row = Integer.parseInt(buffer.readLine().split(",")[1]);
            sheetData._column = Integer.parseInt(buffer.readLine().split(",")[1]);

            //Read data for the header
            sheetData._client = buffer.readLine().split(",")[1];
            sheetData._site = buffer.readLine().split(",")[1];
            sheetData._room = buffer.readLine().split(",")[1];
            sheetData._date = buffer.readLine().split(",")[1];

            //Tracks how many lines we have currently read in the file
            int counter = 0;

            //Variable stores each line once they are read in to the application
            String line;

            //Read the next line of text from the file, if it is not null (empty) proceed with the loop.
            while ((line=buffer.readLine()) != null)
            {
                //Split the line using the commas into separate elements
                String[] temp = line.split(",");

                //Cycle through the elements of the temp string array, one temp has 5 elements
                for (int i = 0; i < 5; i++)
                {
                    //Object stores cellData
                    CellData cellData = new CellData();

                    //Copy the text from the temp array at the current index number
                    cellData._row = Integer.parseInt(temp[1]);
                    cellData._column = Integer.parseInt(temp[0]);
                    cellData._fixture = temp[2];
                    cellData._color =ColorTrans( temp[3]);
                    cellData._mobility = temp[4];

                    cellDatum[counter] = cellData;
                }

                //Increase the counter to indicate the current column has been written
                counter++;
            }

            //Close the file buffer once writing is finished
            buffer.close();

            //Store cellData Array to Frame data Object
            sheetData._cellDatum = cellDatum;

            //Return the completed Frame data Object to the place this method was called from.
            return sheetData;
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
            //Return null if an error occurs.
            return null;
        }
    }

    /**
     * Save data to RAF file
     * @param sheetDataData store data to be saved
     * @param filePath where the file to be saved
     */
    public void SaveTo_Raf(SheetData sheetDataData, String filePath)
    {
        //Try catch block is required in Java for any operations dealing with an external resource
        //such as a file or database.
        try
        {
            //Create a random access file object to interact with the file
            //It needs to be provided with a file name to write to and the file mode "rw" to allow writing.
            RandomAccessFile raf = new RandomAccessFile(filePath,"rw");

            //Store Grid size data
            raf.seek(0);
            raf.writeInt(sheetDataData._row);
            raf.seek(5);
            raf.writeInt(sheetDataData._column);

            //Store Header date
            raf.seek(10);
            raf.writeUTF(sheetDataData._client);
            raf.seek(60);
            raf.writeUTF(sheetDataData._site);
            raf.seek(110);
            raf.writeUTF(sheetDataData._room);
            raf.seek(160);
            raf.writeUTF(sheetDataData._date);

            //Tracks how many entries we have currently written to file
            int counter = 0;

            //Store Header data
            //Loop the cellData Array
            for (int x = 0; x < sheetDataData._cellDatum.length; x++)
            {
                if(sheetDataData._cellDatum[x] == null)
                {
                    break;
                }
                {
                    //Calculates the starting index for the first entry
                    //If 250 NOT enough for Header Data, will fail
                    int pointer = counter * 50 + 250;

                    //Go to the file position specified by the pointer.
                    raf.seek(pointer);
                    //Write an integer value at this position.

                    raf.writeInt(sheetDataData._cellDatum[x]._row);

                    //Go to the next file position specified by the pointer plus the distance to the next value.
                    raf.seek(pointer + 5);
                    raf.writeInt(sheetDataData._cellDatum[x]._column);

                    //Go to the next file position specified by the pointer plus the distance to the next value.
                    raf.seek(pointer + 15);
                    raf.writeUTF(sheetDataData._cellDatum[x]._fixture);


                    raf.seek(pointer + 35);
                    raf.writeUTF(ColorTrans(sheetDataData._cellDatum[x]._color));

                    raf.seek(pointer + 45);
                    raf.writeUTF(sheetDataData._cellDatum[x]._mobility);

                    //Increase our counter to indicate an entry has been written.
                    counter++;
                }
            }
            //Closes the file connection and finalises the write process.
            raf.close();
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }

    /**
     * Read data from RAF file
     * @param filePath where to find the file to be read
     * @return
     */
    public SheetData Read_Raf(String filePath)
    {
        SheetData sheetData = new SheetData();

        //Create a cellData Array with fixed size of 2500
        CellData[] cellDatum = new CellData[2500];
        //Any operation to external resources in JAVA needs to be done in a try catch block.
        try
        {
            //Create a random access file object to interact with the file.
            //It needs to be provided with a file name to write to and the file mode "rw" to allow writing.
            RandomAccessFile raf = new RandomAccessFile(filePath,"r");

            raf.seek(0);
            sheetData._row = raf.readInt();
            raf.seek(5);
            sheetData._column =  raf.readInt();
            raf.seek(10);
            sheetData._client = raf.readUTF();
            raf.seek(60);
            sheetData._site =  raf.readUTF();
            raf.seek(110);
            sheetData._room = raf.readUTF();
            raf.seek(160);
            sheetData._date =  raf.readUTF();

            //Counter to track how many entries we have read back so far
            int counter = 0;

            //Check if the next pointer position will be larger than the total RAF file size.
            //If not, keep running the loop.
            while (counter * 50 + 250< raf.length())
            {
                CellData cellData = new CellData();
                //Calculate the starting position of the next entity's entry
                int pointer = counter * 50 + 250;
                //Go to the raf file position specified by the pointer value
                raf.seek(pointer);
                //Read the integer value at this position and store it in an integer variable
                cellData._row = raf.readInt();
                //Go to the raf file position specified by the pointer value plus the size of the first value
                raf.seek(pointer + 5);
                //Read the integer value at this position and store it in an integer variable
                cellData._column = raf.readInt();
                //Go to the raf file position specified by the pointer value plus the size of the first 2 values
                raf.seek(pointer + 15);
                cellData._fixture = raf.readUTF();

                raf.seek(pointer + 35);
                cellData._color = ColorTrans(raf.readUTF());

                raf.seek(pointer + 45);
                cellData._mobility = raf.readUTF();

                //Use the retrieved values to put the text into the 2D array at the positions specified by the x and y positions.

                //Increase the counter to confirm an entry has been successfully read back in.
                cellDatum[counter] = cellData;

                counter++;
            }
            //Closes the file connection and finalises the write process.
            raf.close();

            sheetData._cellDatum = cellDatum;

            //Return the data array back to where this method was called from.
            return sheetData;
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
            return null;
        }
    }

    /**
     * Save data to a DAT file
     * @param sheetData store data to be saved
     * @param filePath where the file to be saved
     */
    public void SaveTo_DAT(SheetData sheetData, String filePath)
    {
        try
        {
            //Create a buffered writer to connect to our specified file and perform the writing operations
            BufferedWriter buffer = new BufferedWriter(new FileWriter(filePath));

            //Number count number of cellData on the Grid
            int i = 0;

            //_cellDatum was set to be [2500], read each _cellDatum until _cellDatum[i] is empty
            while (sheetData._cellDatum[i] != null)
            {
                //Write the current element, followed by a comma, on the current line of the file
                buffer.write( sheetData._cellDatum[i]._column + "," +  sheetData._cellDatum[i]._row +
                        "," + sheetData._cellDatum[i]._mobility);

                //Move to next line of cellData
                i++;

                //Start a new line once the current row is finished
                buffer.newLine();
            }

            //Close the file buffer once writing is finished
            buffer.close();
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }



    /**
     * Translate color between Text and Hex_code
     * @param colorIn the color code in String to be translated
     * @return
     *
     * Red=#FBA1B7   Yellow=#FAF0D7  Green=#F3FDE8   Blue=#D2E0FB Purple=#D8B4F8 White=#FFFFFF
     */
    private String ColorTrans (String colorIn)
    {

        return switch (colorIn)
        {
            case "Red" -> "#FBA1B7";
            case "Yellow" -> "#FAF0D7";
            case "Green" -> "#F3FDE8";
            case "Blue" -> "#D2E0FB";
            case "Purple" -> "#D8B4F8";
            case "White" -> "#FFFFFF";
            case "#FBA1B7" -> "Red";
            case "#FAF0D7" -> "Yellow";
            case "#F3FDE8" -> "Green";
            case "#D2E0FB" -> "Blue";
            case "#D8B4F8" -> "Purple";
            case "#FFFFFF" -> "White";
            default -> "";
        };
    }
}
