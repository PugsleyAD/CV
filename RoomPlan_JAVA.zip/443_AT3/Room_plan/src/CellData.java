/**
 * Object stores cell data required on the Grid
 */
public class CellData
{
     int _row, _column;
     String _fixture;
     String _color;
     String _mobility;

    /**
     * Empty constructor
     */
    public CellData(){};

    /**
     * Constructor with data
     * @param row       row of the cell locates on the Grid
     * @param column    column of the cell locates on the Grid
     * @param fixture   text content show on the cell
     * @param color     color of the background of the cell
     * @param mobility  indicate whether the cell with furniture movable or Not
     */
    public CellData(int row, int column, String fixture, String color, String mobility)
    {
        _row = row;
        _column = column;
        _fixture = fixture;
        _color= color;
        _mobility = mobility;
    }
}
