/**
 * Class stores statistic of furniture on the Grid
 */
public class DataForSort implements Comparable
{

    public String _fixture;

    //number of the furniture found on the Grid
    public int _count;

    //Constructor with no parameters
    public DataForSort() {}

    //Constructor with 2 parameters
    public DataForSort(String fixture, int count)
    {
        _fixture = fixture;
        _count = count;
    }

    @Override
    public int compareTo(Object other)
    {
        //Convert and store the other object in a variable as its original type.
        DataForSort otherFixture = (DataForSort)other;
        //Compare the text of the other object against the text of this object and return the result.
        return _fixture.compareTo(otherFixture._fixture);
    }
}
