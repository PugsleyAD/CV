import jdk.dynalink.beans.StaticClass;

import javax.swing.*;
import javax.swing.plaf.synth.ColorType;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Start up the application
 */
public class Main {
    public static void main(String[] args)
    {
        //Create the MainForm with 13 rows and 13 columns by default
        MainForm mainForm = new MainForm(12, 12);

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                mainForm.repaint();
            }
        });

    }

}



//Timer to refresh the MainForm
//                java.util.Timer timer = new Timer();
//
//                TimerTask task1 = new TimerTask()
//                {
//                    @Override
//                    public void run()
//                    {
//                        mainForm.setExtendedState(JFrame.ICONIFIED);
//                    }
//                };
//
//                timer.schedule(task1, 200);
//
//                TimerTask task2 = new TimerTask()
//                {
//                    @Override
//                    public void run()
//                    {
//                        mainForm.setExtendedState(JFrame.NORMAL);
//                    }
//                };
//
//                timer.schedule(task2, 200);