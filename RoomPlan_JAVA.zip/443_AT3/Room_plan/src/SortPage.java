import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.LinkedList;

/**
 * Class to pop a window counting furniture and its number on the MainForm
 */
public class SortPage extends JFrame
{
    FlowLayout flowLayout = new FlowLayout();
    GridLayout gridLayout;
    JPanel pnlFixture = new JPanel();
    JPanel pnlCount = new JPanel();
    JLabel lblFixture = new JLabel("Furniture");
    JLabel lblCount = new JLabel("Count");
    JLabel lblBlank_1 = new JLabel();
    JLabel lblBlank_2 = new JLabel();
    LinkedList<DataForSort> dataForSortList;
    JLabel[][] labelsArray;

    /**
     * Set up layout and fill the popup page
     * @param dataForSort statistics of furniture on the MainForm
     */
    public SortPage(LinkedList<DataForSort> dataForSort)
    {
        dataForSortList = dataForSort;

        int rowsOfList = dataForSortList.size();

        setLocation(400,100);
        setLayout(flowLayout);
        setResizable(false);

        gridLayout = new GridLayout(rowsOfList+2, 1);
        pnlFixture.setLayout(gridLayout);
        pnlCount.setLayout(gridLayout);

        Font title = new Font("", 1, 18);

        lblFixture.setHorizontalAlignment(JLabel.CENTER);
        lblFixture.setFont(title);
        lblCount.setHorizontalAlignment(JLabel.CENTER);
        lblCount.setFont(title);

        pnlFixture.add(lblFixture);
        pnlFixture.add(lblBlank_1);
        pnlCount.add(lblCount);
        pnlCount.add(lblBlank_2);

        lblFixture.setOpaque(true);
        lblCount.setOpaque(true);
        lblFixture.setBackground(Color.decode("#FFCF96"));
        lblCount.setBackground(Color.decode("#FFCF96"));

        //Set the size of the array to match the number of entries passed over in the text count list.
        labelsArray = new JLabel[2][dataForSortList.size()];

        for(int i=0; i<dataForSortList.size(); i++)
        {
            labelsArray[0][i] = new JLabel();
            labelsArray[0][i].setPreferredSize(new Dimension(90, 30));
            labelsArray[0][i].setHorizontalAlignment(JLabel.CENTER);
            pnlFixture.add(labelsArray[0][i]);

            labelsArray[1][i] = new JLabel();
            labelsArray[1][i].setPreferredSize(new Dimension(90, 30));
            labelsArray[1][i].setHorizontalAlignment(JLabel.CENTER);
            pnlCount.add(labelsArray[1][i]);

            //Get the fixture from the current fixture list entry
            String fixture = dataForSortList.get(i)._fixture;
            //get the count value from the current fixture list entry and convert it ot a string.
            String count = "" + dataForSortList.get(i)._count;
            //Add the 2 values to their columns in the current textArray row

            labelsArray[0][i].setText(fixture);
            labelsArray[1][i].setText(count);
        }

        add(pnlFixture);
        add(pnlCount);
        pnlFixture.setVisible(true);
        pnlCount.setVisible(true);
        pack();
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                //Clears the form from memory. not too much of an issue in small projects but is useful in bigger ones
                dispose();
            }
        });
    }
}
