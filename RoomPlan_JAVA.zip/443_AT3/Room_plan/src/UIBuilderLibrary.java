//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class UIBuilderLibrary {
    public UIBuilderLibrary() {
    }

    //Build Label from NorthWestAnchor of window
    public static JLabel BuildJLabelWithNorthWestAnchor(String text, int hPad, int vPad, SpringLayout layout, Component other) {
        JLabel myLabel = new JLabel(text);
        layout.putConstraint("West", myLabel, hPad, "West", other);
        layout.putConstraint("North", myLabel, vPad, "North", other);
        return myLabel;
    }

    //Build Label to Right of a component
    public static JLabel BuildJLabelInlineToRight(String text, int hPad, SpringLayout layout, Component other) {
        JLabel myLabel = new JLabel(text);
        layout.putConstraint("West", myLabel, hPad, "East", other);
        layout.putConstraint("North", myLabel, 0, "North", other);
        return myLabel;
    }

    //Build Label below a component
    public static JLabel BuildJLabelInlineBelow(String text, int vPad, SpringLayout layout, Component other) {
        JLabel myLabel = new JLabel(text);
        layout.putConstraint("West", myLabel, 0, "West", other);
        layout.putConstraint("North", myLabel, vPad, "South", other);
        return myLabel;
    }

    //Build TextField from NorthWestAnchor of window
    public static JTextField BuildJTextFieldWithNorthWestAnchor(int size, int hPad, int vPad, SpringLayout layout, Component other) {
        JTextField myTextField = new JTextField(size);
        layout.putConstraint("West", myTextField, hPad, "West", other);
        layout.putConstraint("North", myTextField, vPad, "North", other);
        return myTextField;
    }

    //Build TextField to Right of a component
    public static JTextField BuildJTextFieldInlineToRight(int size, int hPad, SpringLayout layout, Component other) {
        JTextField myTextField = new JTextField(size);
        layout.putConstraint("West", myTextField, hPad, "East", other);
        layout.putConstraint("North", myTextField, 0, "North", other);
        return myTextField;
    }

    //Build TextField below a component
    public static JTextField BuildJTextFieldInlineBelow(int size, int vPad, SpringLayout layout, Component other) {
        JTextField myTextField = new JTextField(size);
        layout.putConstraint("West", myTextField, 0, "West", other);
        layout.putConstraint("North", myTextField, vPad, "South", other);
        return myTextField;
    }

    //Build Button from NorthWestAnchor of window
    public static JButton BuildJButtonWithNorthWestAnchor(int width, int height, String text, int hPad, int vPad, ActionListener listener, SpringLayout layout, Component other) {
        JButton myButton = new JButton(text);
        myButton.setPreferredSize(new Dimension(width, height));
        myButton.addActionListener(listener);
        layout.putConstraint("West", myButton, hPad, "West", other);
        layout.putConstraint("North", myButton, vPad, "North", other);
        return myButton;
    }

    //Build Button to Right of a component
    public static JButton BuildJButtonInlineToRight(int width, int height, String text, int hPad, ActionListener listener, SpringLayout layout, Component other) {
        JButton myButton = new JButton(text);
        myButton.setPreferredSize(new Dimension(width, height));
        myButton.addActionListener(listener);
        layout.putConstraint("West", myButton, hPad, "East", other);
        layout.putConstraint("North", myButton, 0, "North", other);
        return myButton;
    }

    //Build Button below a component
    public static JButton BuildJButtonInlineBelow(int width, int height, String text, int vPad, ActionListener listener, SpringLayout layout, Component other) {
        JButton myButton = new JButton(text);
        myButton.setPreferredSize(new Dimension(width, height));
        myButton.addActionListener(listener);
        layout.putConstraint("West", myButton, 0, "West", other);
        layout.putConstraint("North", myButton, vPad, "South", other);
        return myButton;
    }
}
