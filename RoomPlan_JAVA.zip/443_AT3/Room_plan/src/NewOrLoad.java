import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * A separate window allow user to choose to create a new room_plan or open an existing one
 */
public class NewOrLoad extends JFrame implements ActionListener
{
    SpringLayout springLayout = new SpringLayout();
    JLabel lblRow, lblColumn, lblOr;
    JTextField txtRow, txtColumn;
    JButton btnNew, btnOpen;

    //int store row and column
    int row = 0;
    int column = 0;

    FileIO fileIo = new FileIO();

    /**
     * Set up the layout of the window
     */
    public NewOrLoad()
    {
        this.setLocation(400,200);
        this.setSize(230, 230);
        this.setLayout(springLayout);
        this.setResizable(false);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        lblRow = UIBuilderLibrary.BuildJLabelWithNorthWestAnchor("Row: ", 10, 20, springLayout, this);
        txtRow = UIBuilderLibrary.BuildJTextFieldInlineToRight(10, 30, springLayout, lblRow);
        lblColumn = UIBuilderLibrary.BuildJLabelInlineBelow("Column: ", 10, springLayout, lblRow);
        txtColumn = UIBuilderLibrary.BuildJTextFieldInlineBelow(10, 5, springLayout, txtRow);

        btnNew = UIBuilderLibrary.BuildJButtonInlineBelow(80, 20, "NEW", 10, this, springLayout, txtColumn);
        lblOr = UIBuilderLibrary.BuildJLabelInlineBelow("", 10, springLayout, btnNew);
        lblOr.setPreferredSize(new Dimension(230, 30));
        btnOpen = UIBuilderLibrary.BuildJButtonInlineBelow(80, 20, "OPEN", 10, this, springLayout, lblOr);

        this.add(lblRow);
        this.add(txtRow);
        this.add(lblColumn);
        this.add(txtColumn);
        this.add(btnNew);
        this.add(lblOr);
        this.add(btnOpen);

        this.setVisible(true);
    }

    /**
     * ActionListener responding to click on button NEW and button OPEN
     * @param e the event to be processed
     */
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == this.btnNew) {
            try {
                row = Integer.parseInt(txtRow.getText());
                column = Integer.parseInt(txtColumn.getText());
            } catch (Exception ex) {
                ex.getMessage();
            }

            if (row != 0 && column != 0) {
                //use invokeLater to transfer row and column to planForm
                EventQueue.invokeLater(() ->
                {
                    MainForm mainForm = new MainForm(row+1, column+1);

                    //Another function in Swing to invokeLater
                    SwingUtilities.invokeLater(new Runnable() {
                        @Override
                        public void run() {
                            mainForm.repaint();
                        }
                    });
                });

                //close the NewOrLoad windows
                this.dispose();

            } else {
                txtRow.setText("");
                txtColumn.setText("");
                JOptionPane.showMessageDialog(this, "Please enter ONLY Positive Integer for Rows and Columns", "ONLY+++", JOptionPane.PLAIN_MESSAGE);
            }
        }

        if (e.getSource() == btnOpen) {
            SheetData sheetData = SelectAndLoadFileData();

            //Can switch layout of rows and columns
            if(sheetData!=null)
            {
                row = sheetData._row;
                column = sheetData._column;

                MainForm mainForm = new MainForm(row+1, column+1);
                ShowData(mainForm, sheetData);

                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        mainForm.repaint();
                    }
                });

                //close the NewOrLoad windows
                this.dispose();
            }

        }

    }

    /**
     * Paint the MainForm
     * @param mainForm which is to be paint
     * @param sheetData store data about how the MainForm to be paint
     */
    public void ShowData(MainForm mainForm, SheetData sheetData)
    {
        //Somewhere here you will pass the header data from the model into the header text fields
        mainForm.txtClient.setText(sheetData._client);
        mainForm.txtSite.setText(sheetData._site);
        mainForm.txtRoom.setText(sheetData._room);
        mainForm.txtDate.setText(sheetData._date);

        int counter = 0;
        while(sheetData._cellDatum[counter] != null)
        {
            mainForm.txtGrid[sheetData._cellDatum[counter]._row][sheetData._cellDatum[counter]._column].setText(sheetData._cellDatum[counter]._fixture);
            mainForm.txtGrid[sheetData._cellDatum[counter]._row][sheetData._cellDatum[counter]._column].setBackground(Color.decode(sheetData._cellDatum[counter]._color));
            mainForm.txtGrid[sheetData._cellDatum[counter]._row][sheetData._cellDatum[counter]._column].setName(sheetData._cellDatum[counter]._mobility);
            counter++;
        }

        //Repaint the Fixed items(increse border size) on the Mainform created after
        EventQueue.invokeLater(new Runnable ()
        {
            @Override
            public void run()
            {
                for(int i = 0; i < row + 1; i++)
                {
                    for (int j = 0; j < column + 1; j++)
                    {
                        //First check if TextField object on the txtArray has Name, if so, then check name
                        if(mainForm.txtGrid[i][j].getName() != null && mainForm.txtGrid[i][j].getName().equals("No"))
                        {
                            mainForm.txtGrid[i][j].setBorder(BorderFactory.createLineBorder(Color.GRAY, 3));
                        }
                    }
                }
            }

        });
    }

    /**
     * Object store data indicating how the MainForm to be painted
     * @return
     */
    private SheetData SelectAndLoadFileData()
    {
        //Creates a file dialog to allow the user to choose which file they want top open.
        FileDialog dialog = new FileDialog(this, "Select .csv or .raf file to Open.", FileDialog.LOAD);
        //Make the file dialog visible on screen. This will lock the parent screen until the user is finished with the dialog.
        dialog.setVisible(true);
        //Get the name of the file selected by the user,
        String fileName = dialog.getFile();
        //If the selected file is null or empty, meaning they did not select a file or pressed cancel.
        if (fileName == null || fileName.isEmpty())
        {
            //Post a message to the user and return null;
            return null;
        }
        //Create a variable to hold our filedata
        SheetData sheetData;
        //Get the absolute file path of the file to be loaded
        String filePath = dialog.getDirectory() + fileName;
        //Check the file path extension. If the extension is .csv or .raf, load the file with the correct method.
        //Otherwise, post an error message to the user.
        if (filePath.endsWith(".csv"))
        {
            //Read the file using the CSV reading method.
            sheetData = fileIo.Read_Csv(filePath);
        }
        else if(filePath.endsWith(".raf"))
        {
            //Read the file using the RAF reading method.
            sheetData = fileIo.Read_Raf(filePath);
        }
        else
        {
            //Inform the user of the issue and set the fileData variable to null;
            JOptionPane.showMessageDialog(this,"The selected file was not a valid type.");
            sheetData = null;
        }
        //Return the fileData contents.
        return sheetData;
    }

}

