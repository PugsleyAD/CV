/**
 * Object stores all data required on the MainForm
 */
public class SheetData
{
    public int _row;
    public int _column;
    public String _client;
    public String _site;
    public String _room;
    public String _date;
    public CellData[] _cellDatum;

    /**
     * Empty constructor
     */
    public SheetData()
    {

    }

    /**
     * Constructor with data
     * @param row       number of rows of the Grid
     * @param column    number of columns of the Grid
     * @param client    user's name
     * @param site      address of the site
     * @param room      location of the room
     * @param date      date modifying the plan
     * @param cellDatum data of each cell on the Grid
     */
    public SheetData(int row, int column, String client, String site, String room, String date, CellData[] cellDatum)
    {
        _row = row;
        _column = column;
        _client = client;
        _site = site;
        _room = room;
        _date = date;

        _cellDatum = cellDatum;

    }
}
